<?php


class CliqueRetire_Envia_Block_Carrier_Cliqueretire extends Mage_Core_Block_Template
{
}
